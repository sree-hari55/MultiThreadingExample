package com.app;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.stream.Collectors;

import com.app.service.ProfileInfo;
import com.app.service.ProfileServiceImpl;

public class JoinMethodExample {

	public static void main(String[] args) {
		Executor exe=Executors.newFixedThreadPool(2);

		List<ProfileInfo> future=CompletableFuture.supplyAsync( () ->{
			System.out.println("thread details:"+Thread.currentThread().getName());
			return ProfileServiceImpl.getProfileInfos();
		},exe).thenApplyAsync( (profileInfo) -> {
			System.out.println("thread details:"+Thread.currentThread().getName());
			return profileInfo.stream()
					.filter((p) -> "fullyregistration".equals(p.getProfileType()))
					.collect(Collectors.toList());
		},exe).join();
		
		System.out.println(future);
		
	}

}
