package com.app;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class RunAsyncMethodExample {

	public static void main(String[] args) throws InterruptedException, ExecutionException {


		Future<Void> future=CompletableFuture.runAsync(()->{
		
			System.out.println("run async ex");
			System.out.println("Thread Name:"+Thread.currentThread().getName());
		});

		System.out.println(future.get());

		Executor exeService=Executors.newFixedThreadPool(1);
		Future<Void> exeFuture=CompletableFuture.runAsync(()->{

			System.out.println("run async ex with executor service");
			System.out.println("Thread Name:"+Thread.currentThread().getName());
		},exeService);

		System.out.println(exeFuture.get());

	}

}
