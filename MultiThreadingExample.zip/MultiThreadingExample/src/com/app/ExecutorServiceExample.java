package com.app;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class ExecutorServiceExample {

	public static void main(String[] args) throws InterruptedException, ExecutionException {
		/**
		 * java 5 - Executors / Futures
		 * 
		 * The Java.util.concurrent API adds Executors.
		 * 
		 * You can use multiple factory methods of the Executors class to create an Executor Service:
		 * 
		 * You can think of an Executor service as an abstraction over a pool of threads and a task queue which you can submit your Runnable’s and Callable’s to.
		 * 
		 * 
		 * When a thread becomes available it will pick up the next task in the queue to execute and a Future Object will be returned to represent the state of this task.
		 * 
		 * **/

		Runnable r=()->{
			try {
				Thread.sleep(11111);
				System.out.println("Runnable implementation:"+ Thread.currentThread().getName());
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		};

		Callable<String> c=()->{
			System.out.println("callable implementation:"+ Thread.currentThread().getName());
			return "callable Implemenattion";
		};

		ExecutorService service= Executors.newFixedThreadPool(1);

		// Runnable Example 
		Future<?> future=service.submit(r);
		Future<?> future2=service.submit(r, "completed");

		System.out.println(future.get());
		System.out.println(future2.get());

		// callable example

		Future<?> cFuture=service.submit(c);
		System.out.println(cFuture.get());

	}

}
