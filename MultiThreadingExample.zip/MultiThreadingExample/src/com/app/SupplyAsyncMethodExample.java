package com.app;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class SupplyAsyncMethodExample {

	public static void main(String[] args) throws InterruptedException, ExecutionException {
		Future<String> future=CompletableFuture.supplyAsync(()->{
			System.out.println("Thread Name:"+Thread.currentThread().getName());
			return "supply async ex";
		});

		System.out.println(future.get());

		Executor exeService=Executors.newFixedThreadPool(1);
		Future<String> exeFuture=CompletableFuture.supplyAsync(()->{
			System.out.println("Thread Name:"+Thread.currentThread().getName());
			return "supply async ex with executor service";
		},exeService);

		System.out.println(exeFuture.get());
	}

}
