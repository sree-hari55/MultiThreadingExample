package com.app;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class ThreadExample {

	public static void main(String[] args) {
		System.out.println("main Thread:"+ Thread.currentThread().getName());
		Runnable r=()->{
			try {
				Thread.sleep(11111);
				System.out.println("Runnable implementation"+ Thread.currentThread().getName());
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		};

		Thread t=new Thread(r);
		t.start();

		Callable<String> c=()->{
			System.out.println("callable implementation:"+ Thread.currentThread().getName());
			return "callable Implemenattion";
		};

		ExecutorService executorService = Executors.newFixedThreadPool(1);
		Future<String> future1 = executorService.submit(c);
		try {
			System.out.println(future1.get());
		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (ExecutionException e) {
			e.printStackTrace();
		}

	}
}
