package com.app;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.stream.Collectors;

import com.app.service.ProfileServiceImpl;

public class ThenApplyMethodExample {

	public static void main(String[] args) {
		Executor exe=Executors.newFixedThreadPool(2);

		CompletableFuture.supplyAsync( () ->{
			System.out.println("thread details:"+Thread.currentThread().getName());
			return ProfileServiceImpl.getProfileInfos();
		},exe).thenApplyAsync( (profileInfo) -> {
			System.out.println("thread details:"+Thread.currentThread().getName());
			return profileInfo.stream()
					.filter((p) -> "fullyregistration".equals(p.getProfileType()))
					.collect(Collectors.toList());
		},exe).thenApplyAsync((profileInfo) ->{
			System.out.println("thread details:"+Thread.currentThread().getName());
			return profileInfo.stream()
					.map((p) -> p.getUserName())
					.collect(Collectors.toList());
		},exe).thenAcceptAsync((email) ->{
			System.out.println("thread details:"+Thread.currentThread().getName());
			System.out.println("email:"+email);
		},exe);
	}

}
